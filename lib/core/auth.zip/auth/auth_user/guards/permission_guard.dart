// lib/shared/widgets/permission_guard.dart
import 'package:afyakit/core/auth/shared/models/auth_user_model.dart';
import 'package:flutter/material.dart';

class PermissionGuard extends StatelessWidget {
  final AuthUser? user; // allow null
  final bool Function(AuthUser) allowed;
  final Widget child;
  final Widget fallback;

  const PermissionGuard({
    super.key,
    required this.user,
    required this.allowed,
    required this.child,
    this.fallback = const SizedBox.shrink(),
  });

  @override
  Widget build(BuildContext context) {
    final u = user;
    if (u == null) return fallback;
    return allowed(u) ? child : fallback;
  }
}
